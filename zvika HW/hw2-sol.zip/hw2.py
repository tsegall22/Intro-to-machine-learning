import numpy as np
np.random.seed(42)

chi_table = {0.01  : 6.635,
             0.005 : 7.879,
             0.001 : 10.828,
             0.0005 : 12.116,
             0.0001 : 15.140,
             0.00001: 19.511}

def calc_gini(data):
    """
    Calculate gini impurity measure of a dataset.

    Input:
    - data: any dataset where the last column holds the labels.

    Returns the gini impurity of the dataset.    
    """
    gini = 0.0
    ###########################################################################
    # TODO: Implement the function.                                           #
    ###########################################################################
    labels, counts = np.unique(data[:,-1], return_counts = True)
    total_count = np.sum(counts)
    gini = 1 - np.sum(np.square(counts / total_count))
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return gini

def calc_entropy(data):
    """
    Calculate the entropy of a dataset.

    Input:
    - data: any dataset where the last column holds the labels.

    Returns the entropy of the dataset.    
    """
    entropy = 0.0
    ###########################################################################
    # TODO: Implement the function.                                           #
    ###########################################################################
    labels, counts = np.unique(data[:,-1], return_counts = True)
    total_count = np.sum(counts)
    class_frac = counts / total_count
    entropy = np.sum(-class_frac * np.log2(class_frac))
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return entropy

class DecisionNode:

    # This class will hold everything you require to construct a decision tree.
    # The structure of this class is up to you. However, you need to support basic 
    # functionality as described in the notebook. It is highly recommended that you 
    # first read and understand the entire exercise before diving into this class.
    
    def __init__(self, feature, value, data):
        self.feature = feature # column index of criteria being tested
        self.value = value # value necessary to get a true result
        self.data = data # data set needed for this particular node
        self.children = []
        self.parent = None
        
    def add_child(self, node):
        self.children.append(node)
        
    # zero indexed child is always the greater considering the value (threshold)
    def get_child(self, attribute_value):
        is_greatereq = attribute_value >= self.value
        if self.is_leaf():
            return None
        if is_greatereq:
            return self.children[0]
        return self.children[1]
    
    def is_leaf(self):
        return len(self.children) == 0
    
    def node_class(self):
        labels, counts = np.unique(self.data[:, -1], return_counts=True)
        return labels[np.argmax(counts)]

    def set_parent(self, parent):
        self.parent = parent

def build_tree(data, impurity, chi_pvalue = 1):
    """
    Build a tree using the given impurity measure and training dataset. 
    You are required to fully grow the tree until all leaves are pure. 

    Input:
    - data: the training dataset.
    - impurity: the chosen impurity measure. Notice that you can send a function
                as an argument in python.

    Output: the root node of the tree.
    """
    root = None
    ###########################################################################
    # TODO: Implement the function.                                           #
    ###########################################################################
    node_impurity = impurity(data)
    max_delta = 0
    max_threshold = None
    max_feature = None
    max_greatereq = None
    max_smaller = None
    if np.isclose(node_impurity, 0):
        return DecisionNode(None, None, data)
    
    for feature in range(len(data[0])-1):
        for threshold in get_threshold(data[:,feature]):
            split_greatereq, split_smaller = split_data(data,feature,threshold)
            weighted_child_impurity = impurity(split_greatereq) * len(split_greatereq) / len(data) + impurity(split_smaller) * len(split_smaller) / len(data)
            delta_impurity = node_impurity - weighted_child_impurity
            if delta_impurity > max_delta:
                max_delta = delta_impurity
                max_threshold = threshold
                max_feature = feature
                max_greatereq = split_greatereq
                max_smaller = split_smaller
    root = DecisionNode(max_feature, max_threshold, data)
    if chi_pvalue != 1:
        p_y0 = (data[:, -1] == 0).sum() / len(data)
        chi_sq = calc_chi(max_greatereq, max_smaller, p_y0)
        if chi_sq <= chi_table[chi_pvalue]:
            return root
    t1 = build_tree(max_greatereq, impurity, chi_pvalue)
    t1.parent = root
    root.add_child(t1)
    t2 = build_tree(max_smaller, impurity, chi_pvalue)
    t2.parent = root
    root.add_child(t2)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return root

def calc_chi(greatereq_set, smaller_set, prob_y0):
    df = np.array([len(greatereq_set), len(smaller_set)])
    counts_great = np.array([(greatereq_set[:,-1] == 0.).sum(), (greatereq_set[:,-1] == 1.).sum()])
    counts_small = np.array([(smaller_set[:,-1] == 0.).sum(), (smaller_set[:,-1] == 1.).sum()])
    pf = np.array([counts_great[0], counts_small[0]])
    nf = np.array([counts_great[1], counts_small[1]])
    e0 = df * prob_y0
    e1 = df * (1 - prob_y0)
    
    chi_sq = 0
    for i in range(2):
        chi_sq += (np.square(pf[i] - e0[i]) / e0[i]) + (np.square(nf[i] - e1[i]) / e1[i])
    return chi_sq
    
def count_nodes(node):
    if node.is_leaf():
        return 0
    return count_nodes(node.children[0]) + count_nodes(node.children[1]) + 1

def get_leaves(node):
    if node.is_leaf():
        return [node]
    return get_leaves(node.children[0]) + get_leaves(node.children[1])
#
# def get_leaves(node, leaves):
#     if node.is_leaf():
#         leaves.append(node)
#         return
#     get_leaves(node.children[0], leaves)
#     get_leaves(node.children[1], leaves)
    
def get_threshold(data):
    res = np.empty(len(data)-1)
    sortedData = np.sort(data)
    for i in range(len(sortedData)-1):
        res[i] = (sortedData[i] + sortedData[i+1])/ 2
    return res

def split_data(data, feature, threshold):
    mask = data[:,feature]>=threshold
    split_greatereq = data[mask, :]
    split_smaller = data[~mask, :]
    return split_greatereq, split_smaller
        
def predict(node, instance):
    """
    Predict a given instance using the decision tree

    Input:
    - root: the root of the decision tree.
    - instance: an row vector from the dataset. Note that the last element 
                of this vector is the label of the instance.

    Output: the prediction of the instance.
    """
    pred = None
    ###########################################################################
    # TODO: Implement the function.                                           #
    ###########################################################################
    current = node
    while not current.is_leaf():
        current = current.get_child(instance[current.feature])

    pred = current.node_class()
        
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return pred

def calc_accuracy(node, dataset):
    """
    calculate the accuracy starting from some node of the decision tree using
    the given dataset.

    Input:
    - node: a node in the decision tree.
    - dataset: the dataset on which the accuracy is evaluated

    Output: the accuracy of the decision tree on the given dataset (%).
    """
    accuracy = 0.0
    ###########################################################################
    # TODO: Implement the function.                                           #
    ###########################################################################
    count_correct = 0
    for row in dataset:
        if predict(node, row) == row[-1]:
            count_correct += 1
    accuracy = 100 * count_correct / len(dataset) 
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return accuracy

def print_tree(node):
    '''
    prints the tree according to the example in the notebook

	Input:
	- node: a node in the decision tree

	This function has no return value
	'''

    ###########################################################################
    # TODO: Implement the function.                                           #
    ###########################################################################    
    def print_tree_rec(node, indent):
        if node.is_leaf():
            labels, counts = np.unique(node.data[:, -1], return_counts=True)
            for i in range(len(labels)):
                print(indent * ' ' * 2 + 'leaf: [{}:{}]'.format(labels[i], counts[i]))
            return
        print(indent * ' ' * 2 + '[X{} <= {}]'.format(node.feature, node.value))
        print_tree_rec(node.children[0], indent + 1)
        print_tree_rec(node.children[1], indent + 1)

    print_tree_rec(node, 0)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
