import numpy as np
import timeit

# Dimension 231
def phi(source):
	target1 = np.array([1])
	target2 = np.sqrt(2) * source
	target3 = source * source
	target4 = source[:, np.newaxis] * source[np.newaxis, :]
	target4 = np.sqrt(2) * target4[np.triu_indices(20, 1)]
	return np.concatenate((target1, target2, target3, target4))

data = np.random.rand(20000, 20)

gram_mat_kernel = (data.dot(data.T) + 1)**2
data_mapped = np.vstack(phi(data[i, :]) for i in range(len(data)))
gram_mat_mapped = data_mapped.dot(data_mapped.T)
is_similar = np.all(np.isclose(gram_mat_kernel, gram_mat_mapped))
print(is_similar)

kernel_string = "(data.dot(data.T) + 1)**2"
mapping_string = """\
data_mapped = np.vstack(phi(data[i, :]) for i in range(len(data)))
gram_mat_mapped = data_mapped.dot(data_mapped.T)
"""
print(timeit.timeit(stmt=kernel_string, number=1, globals=globals()))
print(timeit.timeit(stmt=mapping_string, number=1, globals=globals()))


