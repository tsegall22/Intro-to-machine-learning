from numpy import count_nonzero, logical_and, logical_or, concatenate, mean, array_split, poly1d, polyfit, array, linspace
from numpy.random import permutation
import pandas as pd
from sklearn.svm import SVC
import matplotlib.pyplot as plt


SVM_DEFAULT_DEGREE = 3
SVM_DEFAULT_GAMMA = 'auto'
SVM_DEFAULT_C = 1.0
ALPHA = 1.5


def prepare_data(data, labels, max_count=None, train_ratio=0.8):
    """
    :param data: a numpy array with the features dataset
    :param labels:  a numpy array with the labels
    :param max_count: max amout of samples to work on. can be used for testing
    :param train_ratio: ratio of samples used for train
    :return: train_data: a numpy array with the features dataset - for train
             train_labels: a numpy array with the labels - for train
             test_data: a numpy array with the features dataset - for test
             test_labels: a numpy array with the features dataset - for test
    """
    if max_count:
        data = data[:max_count]
        labels = labels[:max_count]

    train_data = array([])
    train_labels = array([])
    test_data = array([])
    test_labels = array([])

    ###########################################################################
    # TODO: Implement the function                                            #
    ###########################################################################
    shuffled = permutation(concatenate((data,labels.reshape(-1,1)),axis=1))
    slice_index = (int)(len(shuffled)*train_ratio)
    training_subset = shuffled[:slice_index]
    test_subset = shuffled[slice_index:]
    train_data = training_subset[:, :-1]
    train_labels = training_subset[:, -1]
    test_data = test_subset[:, :-1]
    test_labels = test_subset[:, -1]
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return train_data, train_labels, test_data, test_labels


def get_stats(prediction, labels):
    """
    :param prediction: a numpy array with the prediction of the model
    :param labels: a numpy array with the target values (labels)
    :return: tpr: true positive rate
             fpr: false positive rate
             accuracy: accuracy of the model given the predictions
    """

    tpr = 0.0
    fpr = 0.0
    accuracy = 0.0

    ###########################################################################
    # TODO: Implement the function                                            #
    ###########################################################################
    logical_or_res = logical_or(prediction, labels)
    tp = count_nonzero(logical_and(prediction, labels))
    fp = count_nonzero(logical_or_res - labels)
    tn = len(prediction) - count_nonzero(logical_or_res)
    fn = count_nonzero(logical_or_res - prediction)
    
    tpr = tp / (tp + fn)
    fpr = fp / (fp + tn)
    accuracy = (tp + tn) / len(prediction)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return tpr, fpr, accuracy


def get_k_fold_stats(folds_array, labels_array, clf):
    """
    :param folds_array: a k-folds arrays based on a dataset with M features and N samples
    :param labels_array: a k-folds labels array based on the same dataset
    :param clf: the configured SVC learner
    :return: mean(tpr), mean(fpr), mean(accuracy) - means across all folds
    """
    tpr = []
    fpr = []
    accuracy = []

    ###########################################################################
    # TODO: Implement the function                                            #
    ###########################################################################
    for i in range(len(folds_array)):
        val_data = folds_array.pop(i)
        val_label = labels_array.pop(i)
        train_data = concatenate(folds_array)
        train_labels = concatenate(labels_array)
        clf.fit(train_data, train_labels)
        tpr_res, fpr_res, accuracy_res = get_stats(clf.predict(val_data),val_label)
        tpr.append(tpr_res)
        fpr.append(fpr_res)
        accuracy.append(accuracy_res)
        folds_array.insert(i, val_data)
        labels_array.insert(i, val_label)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return mean(tpr), mean(fpr), mean(accuracy)


def compare_svms(data_array,
                 labels_array,
                 folds_count,
                 kernels_list=('poly', 'poly', 'poly', 'rbf', 'rbf', 'rbf',),
                 kernel_params=({'degree': 2}, {'degree': 3}, {'degree': 4}, {'gamma': 0.005}, {'gamma': 0.05}, {'gamma': 0.5},)):
    """
    :param data_array: a numpy array with the features dataset
    :param labels_array: a numpy array with the labels
    :param folds_count: number of cross-validation folds
    :param kernels_list: a list of strings defining the SVM kernels
    :param kernel_params: a dictionary with kernel parameters - degree, gamma, c
    :return: svm_df: a dataframe containing the results as described below
    """
    svm_df = pd.DataFrame()
    svm_df['kernel'] = kernels_list
    svm_df['kernel_params'] = kernel_params
    svm_df['tpr'] = None
    svm_df['fpr'] = None
    svm_df['accuracy'] = None
    ###########################################################################
    # TODO: Implement the function                                            #
    ###########################################################################
    folds_data = array_split(data_array, folds_count)
    folds_label = array_split(labels_array, folds_count)
    for i in range(len(kernels_list)):
        deg = kernel_params[i].get('degree', SVM_DEFAULT_DEGREE)
        gam = kernel_params[i].get('gamma', SVM_DEFAULT_GAMMA)
        c = kernel_params[i].get('c', SVM_DEFAULT_C)
        clf = SVC(kernel=kernels_list[i], degree=deg, gamma=gam, C=c)
        tpr, fpr, accuracy = get_k_fold_stats(folds_data, folds_label, clf)
        svm_df['tpr'][i]=tpr
        svm_df['fpr'][i]=fpr
        svm_df['accuracy'][i]=accuracy
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return svm_df


def get_most_accurate_kernel(accuracy):
    """
    :return: integer representing the row number of the most accurate kernel
    """
    best_kernel = accuracy.astype('float64').idxmax()
    return best_kernel


def get_kernel_with_highest_score(score):
    """
    :return: integer representing the row number of the kernel with the highest score
    """
    best_kernel = score.astype('float64').idxmax()
    return best_kernel


def plot_roc_curve_with_score(df, alpha_slope=1.5):
    """
    :param df: a dataframe containing the results of compare_svms
    :param alpha_slope: alpha parameter for plotting the linear score line
    :return:
    """
    x = df.fpr.tolist()
    y = df.tpr.tolist()

    ###########################################################################
    # TODO: Implement the function                                            #
    ###########################################################################
    plt.scatter(x, y, cmap=plt.cm.get_cmap('Dark2'))
    plt.xlabel("FPR")
    plt.ylabel("TPR")
    max_i = get_kernel_with_highest_score(df['score'])
    b = y[max_i] - alpha_slope * x[max_i]
    x_points = linspace(0,1,1000)
    y_res = alpha_slope * x_points + b
    plt.plot(x_points, y_res, '-r')
    plt.ylim(0.7, 1.1)
    plt.xlim(0,1)
    plt.title('ROC curve')
    plt.show()
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################


def evaluate_c_param(best_kernel_row, data_array, labels_array, folds_count):
    """
    :param data_array: a numpy array with the features dataset
    :param labels_array: a numpy array with the labels
    :param folds_count: number of cross-validation folds
    :return: res: a dataframe containing the results for the different c values. columns similar to `compare_svms`
    """

    res = pd.DataFrame()
    ###########################################################################
    # TODO: Implement the function                                            #
    values1 = [1,2,3]
    values2 = [1, 0, -1, -2, -3, -4]
    c_values = []
    c_values_len = len(values1) * len(values2)
    for j in values1:
        for i in values2:
            c_values.append(10**i * (j / 3))
    kernel_list = (best_kernel_row['kernel'],) * c_values_len
    kernel_params = ()
    for i in range(c_values_len):
        kernel_params += (best_kernel_row['kernel_params'].copy(),)
        kernel_params[i]['c'] = c_values[i]
    res = compare_svms(data_array, labels_array, folds_count, kernel_list, kernel_params)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################
    return res


def get_test_set_performance(best_kernel_row, train_data, train_labels, test_data, test_labels):
    """
    :param train_data: a numpy array with the features dataset - train
    :param train_labels: a numpy array with the labels - train

    :param test_data: a numpy array with the features dataset - test
    :param test_labels: a numpy array with the labels - test
    :return: kernel_type: the chosen kernel type (either 'poly' or 'rbf')
             kernel_params: a dictionary with the chosen kernel's parameters - c value, gamma or degree
             clf: the SVM leaner that was built from the parameters
             tpr: tpr on the test dataset
             fpr: fpr on the test dataset
             accuracy: accuracy of the model on the test dataset
    """

    kernel_type = best_kernel_row['kernel']
    kernel_params = best_kernel_row['kernel_params']
    deg = kernel_params.get('degree', SVM_DEFAULT_DEGREE)
    gam = kernel_params.get('gamma', SVM_DEFAULT_GAMMA)
    c = kernel_params.get('c', SVM_DEFAULT_C)
    clf = SVC(class_weight='balanced', kernel=kernel_type, degree=deg, gamma=gam, C=c)  # TODO: set the right kernel
    tpr = 0.0
    fpr = 0.0
    accuracy = 0.0

    ###########################################################################
    # TODO: Implement the function                                            #
    ###########################################################################
    clf.fit(train_data, train_labels)
    tpr, fpr, accuracy = get_stats(clf.predict(test_data), test_labels)
    ###########################################################################
    #                             END OF YOUR CODE                            #
    ###########################################################################

    return kernel_type, kernel_params, clf, tpr, fpr, accuracy
